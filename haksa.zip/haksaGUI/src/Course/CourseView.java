package Course;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class CourseView extends JFrame {
	private static final long serialVersionUID = 1L;
	JPanel[] mainPanels = new JPanel[3];
	JPanel[] formPanels = new JPanel[3];
	JPanel[] inputPanels = new JPanel[9];
	JLabel titleLabel;
	String[] inputLabelStr = { "�������ڵ�", "�������¸�", "�����⵵", "�����а�", "�����г�",
			"�����б�", "�����ü�", "��米��", "��������" };
	JLabel[] inputLabels = new JLabel[inputLabelStr.length];
	JTextField[] inputFields = new JTextField[4];
	JTextField categoryField;
	JComboBox[] inputBoxs = new JComboBox[5];
	JComboBox<String> categoryBox;
	String[] categoryBtnStr = { "��ȸ", "��ü ��ȸ" };
	JButton[] categoryBtns = new JButton[categoryBtnStr.length];
	String[] submitBtnStr = { "���", "����", "����", "����" };
	JButton[] submitBtns = new JButton[submitBtnStr.length];
	JScrollPane scrollPane;
	JTable table;
	DefaultTableModel dtm;

	public CourseView() {
		this.setTitle("������ ����");
		this.setSize(610, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);

		for (int i = 0; i < mainPanels.length; i++) {
			mainPanels[i] = new JPanel();
			formPanels[i] = new JPanel();
		}
		for (int i = 0; i < inputPanels.length; i++) {
			inputPanels[i] = new JPanel();
		}
		titleLabel = new JLabel("������ ����");
		for (int i = 0; i < inputLabels.length; i++) {
			inputLabels[i] = new JLabel(inputLabelStr[i]);
		}
		for (int i = 0; i < inputFields.length; i++) {
			inputFields[i] = new JTextField(10);
		}
		categoryField = new JTextField(10);
		for (int i = 0; i < inputBoxs.length; i++) {
			inputBoxs[i] = new JComboBox<String>();
		}
		categoryBox = new JComboBox<String>();
		for (int i = 0; i < categoryBtns.length; i++) {
			categoryBtns[i] = new JButton(categoryBtnStr[i]);
		}
		for (int i = 0; i < submitBtns.length; i++) {
			submitBtns[i] = new JButton(submitBtnStr[i]);
		}

		titleLabel.setFont(new Font("����", Font.BOLD, 23));
		titleLabel.setForeground(Color.WHITE);
		mainPanels[0].add(titleLabel);
		mainPanels[0].setBackground(Color.BLACK);
		this.add(mainPanels[0], BorderLayout.NORTH);

		inputBoxs[0].addItem("�����⵵");
		for (int i = 2014; i <= 2021; i++) {
			inputBoxs[0].addItem(i);
		}
		
		inputBoxs[1].addItem("�����а�");
		
		inputBoxs[2].addItem("�����г�");
		inputBoxs[3].addItem("�����б�");
		for (int i = 1; i <= 4; i++) {
			inputBoxs[2].addItem(i + "�г�");
			inputBoxs[3].addItem(i + "�б�");
		}
		inputBoxs[4].addItem("��米��");
		formPanels[0].setLayout(new GridLayout(3, 3));
		formPanels[0].setPreferredSize(new Dimension(600, 200));
		int feildIndex = 0;
		int boxIndex = 0;
		for (int i = 0; i < inputPanels.length; i++) {
			inputPanels[i].add(inputLabels[i]);
			if ((i >= 2 && i <= 5) || i == 7)
				inputPanels[i].add(inputBoxs[boxIndex++]);
			else
				inputPanels[i].add(inputFields[feildIndex++]);
		}
		for (JPanel panel : inputPanels) {
			formPanels[0].add(panel);
		}
		String[] categoryItems = { "�����ڵ�", "������", "�����⵵", "�����а�", "�����г�",
				"�����б�", "�����ü�", "��米��", "����" };
		categoryBox.addItem("�˻��� ī�װ����� ����");
		for (String item : categoryItems) {
			categoryBox.addItem(item);
		}

		formPanels[1].add(categoryBox);
		formPanels[1].add(categoryField);
		for (JButton btn : categoryBtns) {
			btn.setBackground(Color.GREEN);
			btn.setForeground(Color.RED);
			formPanels[1].add(btn);
		}
		formPanels[1].setBackground(Color.BLUE);
		String[][] tableItems = {};
		dtm = new DefaultTableModel(tableItems, categoryItems);
		table = new JTable(dtm);
		scrollPane = new JScrollPane(table);
		scrollPane.setPreferredSize(new Dimension(600, 300));
		formPanels[2].add(scrollPane);

		mainPanels[1].setLayout(new BorderLayout());
		mainPanels[1].add(formPanels[0], BorderLayout.NORTH);
		mainPanels[1].add(formPanels[1], BorderLayout.CENTER);
		mainPanels[1].add(formPanels[2], BorderLayout.SOUTH);
		this.add(mainPanels[1], BorderLayout.CENTER);

		submitBtns[0].setBackground(Color.BLUE);
		submitBtns[1].setBackground(Color.YELLOW);
		submitBtns[2].setBackground(Color.GREEN);
		submitBtns[3].setBackground(Color.PINK);
		submitBtns[0].setForeground(Color.YELLOW);
		submitBtns[1].setForeground(Color.GREEN);
		submitBtns[2].setForeground(Color.RED);
		submitBtns[3].setForeground(Color.WHITE);
		for (JButton btn : submitBtns) {
			btn.setPreferredSize(new Dimension(140, 50));
			mainPanels[2].add(btn);
		}
		this.add(mainPanels[2], BorderLayout.SOUTH);

		new CourseAction(this);
		this.setVisible(true);
	}

	public void close() {
		this.dispose();
	}

	public void BtnAddAction(ActionListener listener) {
		for(JButton btn : submitBtns){
			btn.addActionListener(listener);
		}
		for(JButton btn : categoryBtns){
			btn.addActionListener(listener);
		}
	}

	public void MouseAddAction(MouseAdapter adapter) {
		this.addMouseListener(adapter);
		table.addMouseListener(adapter);
	}

	public void KeyAddAction(KeyListener listener) {
		for(JTextField field : inputFields) {
			field.addKeyListener(listener);
		}
	}
	
}
