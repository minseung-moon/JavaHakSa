package Professor;

import haksa.DBConn;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class ProfessorDAO {
	DBConn conn;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public ProfessorDAO() {
		conn = new DBConn();
		con = conn.conn;
	}

	public void close() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn.conn != null)
				con.close();
		} catch (Exception e) {
			System.out.println("���� ����");
		}
	}

	public ArrayList<ProfessorDTO> selectProfessor() {
		ArrayList<ProfessorDTO> allProfessorDatas = new ArrayList<ProfessorDTO>();

		try {
			String sql = "select * from professor";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProfessorDTO dto = new ProfessorDTO(rs.getString(1),
						rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7),
						rs.getString(8), rs.getString(9), rs.getString(10));
				allProfessorDatas.add(dto);
			}
		} catch (SQLException e) {
			System.out.println("Major�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allProfessorDatas;
	}

	public boolean inserProfessor(ProfessorDTO professor) {
		boolean check = false;

		try {
			String sql = "insert into professor values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, professor.getCode());
			pstmt.setString(2, professor.getName());
			pstmt.setString(3, professor.getUserId());
			pstmt.setString(4, professor.getAddress());
			pstmt.setString(5, professor.getMphone());
			pstmt.setString(6, professor.getHphone());
			pstmt.setString(7, professor.getEnt_year());
			pstmt.setString(8, professor.getDegree());
			pstmt.setString(9, professor.getMajor_code());
			pstmt.setString(10, professor.getRoomno());
			int num = pstmt.executeUpdate();

			if (num == 1)
				check = true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "�̹� �����ϴ� ������ �Դϴ�");
		}
		return check;
	}

	public boolean updateProfessor(ProfessorDTO professor) {
		boolean check = false;

		try {
			String sql = "update professor set name = ?, userId = ?, address = ?, mphone = ?, hphone = ?,"
					+ " ent_year = ?, degree = ?, major_code = ?, roomno = ? where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, professor.getName());
			pstmt.setString(2, professor.getUserId());
			pstmt.setString(3, professor.getAddress());
			pstmt.setString(4, professor.getMphone());
			pstmt.setString(5, professor.getHphone());
			pstmt.setString(6, professor.getEnt_year());
			pstmt.setString(7, professor.getDegree());
			pstmt.setString(8, professor.getMajor_code());
			pstmt.setString(9, professor.getRoomno());
			pstmt.setString(10, professor.getCode());
			int num = pstmt.executeUpdate();
			if (num == 1)
				check = true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "������ ���� �Ͽ����ϴ�");
		}
		return check;
	}

	public boolean deleteProfessor(String code) {
		boolean check = false;

		try {
			String sql = "delete from professor where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				check = true;
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "�������� �ʴ� ���� �Դϴ�!");
			e.printStackTrace();
		}
		return check;
	}

	public ArrayList<ProfessorDTO> selectCategory(int num, String searchStr) {
		ArrayList<ProfessorDTO> allMajorDatas = new ArrayList<ProfessorDTO>();
		String sql = "";
		try {
			if (num == 1) {
				sql = "select * from professor where code = ?";
			} else if (num == 2) {
				sql = "select * from professor where name = ?";
			} else if (num == 3) {
				sql = "select * from professor where userId = ?";
			} else if (num == 4) {
				sql = "select * from professor where address = ?";
			} else if (num == 5) {
				sql = "select * from professor where mphone = ?";
			} else if (num == 6) {
				sql = "select * from professor where hphone = ?";
			} else if (num == 7) {
				sql = "select * from professor where ent_year = ?";
			} else if (num == 8) {
				sql = "select * from professor where degree = ?";
			} else if (num == 9) {
				sql = "select * from professor where major_code = ?";
			} else if (num == 10) {
				sql = "select * from professor where roomno = ?";
			}

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, searchStr);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				ProfessorDTO dto = new ProfessorDTO(rs.getString(1),
						rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getString(7),
						rs.getString(8), rs.getString(9), rs.getString(10));
				allMajorDatas.add(dto);
			}
		} catch (SQLException e) {
			System.out.println(searchStr + "�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allMajorDatas;
	}

}
