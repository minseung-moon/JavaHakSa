package Course;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class CourseAction extends MouseAdapter implements ActionListener, KeyListener {
	private CourseView view;
	private CourseDAO courseDao;
	private CourseDTO courseDto = new CourseDTO(null, null, null, null, null,
			null, null, null, null);
	private int rowIndex = -1;
	private JTable table;
	ArrayList<CourseDTO> selectAll;

	public CourseAction(CourseView view) {
		super();
		this.view = view;
		table = view.table;
		courseDao = new CourseDAO();
		ArrayList<String> major_name = courseDao.selectMajorName();
		ArrayList<String> professor_name = courseDao.selectProfessorNames();
		major_name.forEach(item -> {
			view.inputBoxs[1].addItem(item);
		});
		professor_name.forEach(item -> {
			view.inputBoxs[4].addItem(item);
		});
		view.BtnAddAction(this);
		view.MouseAddAction(this);
		view.KeyAddAction(this);
		initSelect();
	}

	private void initSelect() {
		// ���̺��� �⺻ ������ ���
		view.dtm.setRowCount(0);
		selectAll = courseDao.selectCourse();
		for (CourseDTO select : selectAll) {
			view.dtm.addRow(select.getArrays());
		}
	}

	public void clear() {
		for (JTextField field : view.inputFields) {
			field.setText("");
		}
		view.categoryField.setText("");
		for (JComboBox box : view.inputBoxs) {
			box.setSelectedIndex(0);
		}
		rowIndex = -1;
	}

	private boolean checkInput() {
		boolean check = false;
		for (JTextField field : view.inputFields) {
			if (field.getText() == null || field.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "��ĭ�� ä���ּ���");
				field.requestFocus();
				return check;
			}
		}
		for (JComboBox box : view.inputBoxs) {
			if (box.getSelectedIndex() == 0) {
				JOptionPane.showMessageDialog(null, "�������ּ���");
				box.requestFocus();
				return check;
			}
		}
		check = true;
		courseDto.setCode(view.inputFields[0].getText());
		courseDto.setSubject(view.inputFields[1].getText());
		courseDto.setTime(view.inputFields[2].getText());
		courseDto.setCredit(view.inputFields[3].getText());
		courseDto.setYear(view.inputBoxs[0].getSelectedItem().toString());
		courseDto.setMajor_code(view.inputBoxs[1].getSelectedItem().toString());
		courseDto.setGrade(view.inputBoxs[2].getSelectedItem().toString());
		courseDto.setTerm(view.inputBoxs[3].getSelectedItem().toString());
		courseDto.setProf_code(view.inputBoxs[4].getSelectedItem().toString());
		return check;
	}

	private void selectCategory(int num, String searchStr) {
		// ���̺��� �⺻ ������ ���
		view.dtm.setRowCount(0);
		selectAll = courseDao.selectCategory(num, searchStr);
		for (CourseDTO select : selectAll) {
			view.dtm.addRow(select.getArrays());
		}
	}

	private void updateTable(int rowIndex) {
		table.setValueAt(courseDto.getCode(), rowIndex, 0);
		table.setValueAt(courseDto.getSubject(), rowIndex, 1);
		table.setValueAt(courseDto.getMajor_code(), rowIndex, 2);
		table.setValueAt(courseDto.getYear(), rowIndex, 3);
		table.setValueAt(courseDto.getGrade(), rowIndex, 4);
		table.setValueAt(courseDto.getTerm(), rowIndex, 5);
		table.setValueAt(courseDto.getTime(), rowIndex, 6);
		table.setValueAt(courseDto.getProf_code(), rowIndex, 7);
		table.setValueAt(courseDto.getCredit(), rowIndex, 8);
		JOptionPane.showMessageDialog(null, "���� �Ǿ����ϴ�");
	}

	public void mouseClicked(MouseEvent e) {
		rowIndex = table.getSelectedRow();
		if (rowIndex == -1 || e.getSource() != table) {
			clear();
			return;
		}
		courseDto.setCode(table.getValueAt(rowIndex, 0).toString());
		courseDto.setSubject(table.getValueAt(rowIndex, 1).toString());
		courseDto.setMajor_code(table.getValueAt(rowIndex, 2).toString());
		courseDto.setYear(table.getValueAt(rowIndex, 3).toString());
		courseDto.setGrade(table.getValueAt(rowIndex, 4).toString());
		courseDto.setTerm(table.getValueAt(rowIndex, 5).toString());
		courseDto.setTime(table.getValueAt(rowIndex, 6).toString());
		courseDto.setProf_code(table.getValueAt(rowIndex, 7).toString());
		courseDto.setCredit(table.getValueAt(rowIndex, 8).toString());
		view.inputFields[0].setText(courseDto.getCode());
		view.inputFields[1].setText(courseDto.getSubject());
		view.inputFields[2].setText(courseDto.getTime());
		view.inputFields[3].setText(courseDto.getCredit());
		view.inputBoxs[0].setSelectedItem(courseDto.getYear());
		view.inputBoxs[1].setSelectedItem(courseDto.getMajor_code());
		view.inputBoxs[2].setSelectedItem(courseDto.getGrade());
		view.inputBoxs[3].setSelectedItem(courseDto.getTerm());
		view.inputBoxs[4].setSelectedItem(courseDto.getProf_code());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		if (obj == view.submitBtns[0]) {
			if (!checkInput())
				return;

			int confirm = JOptionPane.showConfirmDialog(null,
					"����" + courseDto.getCode() + "�� �߰��Ͻðڽ��ϱ�?", "�а��߰�",
					JOptionPane.OK_CANCEL_OPTION);
			if (confirm != 0) {
				JOptionPane.showMessageDialog(null, "�а��߰��� ����ϼ̽��ϴ�");
				return;
			}

			if (courseDao.inserCourse(courseDto)) {
				System.out.println(1);
				JOptionPane.showMessageDialog(null, "���忡 �����ϼ̽��ϴ�");
				view.dtm.addRow(courseDto.getArrays());
			} else
				JOptionPane.showMessageDialog(null, "���忡 �����ϼ̽��ϴ�!");
		} else if (obj == view.submitBtns[1]) {
			if (!checkInput())
				return;

			int check = JOptionPane.showConfirmDialog(null, courseDto.getCode()
					+ "�� ���� �Ͻðڽ��ϱ�?", "���� ����", JOptionPane.YES_NO_OPTION);

			if (check == 1) {
				JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�");
				return;
			} else {
				if (rowIndex != -1 && courseDao.updateCourse(courseDto)) {
					updateTable(rowIndex);
				} else if (rowIndex == -1 && courseDao.updateCourse(courseDto)) {
					for (int i = 0; i < view.table.getRowCount(); i++) {
						if (table.getValueAt(i, 0).toString()
								.equals(courseDto.getCode())) {
							rowIndex = i;
							break;
						}
					}
					updateTable(rowIndex);
				} else
					JOptionPane.showMessageDialog(null, "�����ͺ��̽� ������ �����Ͽ����ϴ�!");
			}
		} else if (obj == view.submitBtns[2]) {
			rowIndex = table.getSelectedRow();
			if (rowIndex == -1) {
				JOptionPane.showMessageDialog(null, "������ ���� �������ּ���!");
				return;
			} else {
				String code = table.getValueAt(rowIndex, 0).toString();
				int check = JOptionPane.showConfirmDialog(null, code
						+ "�� ���� �����Ͻðڽ��ϱ�?", "���� ����", JOptionPane.YES_NO_OPTION);
				if (check == 0) {
					if (courseDao.deleteCourse(code)) {
						view.dtm.removeRow(rowIndex);
						JOptionPane.showMessageDialog(null, "���� �Ǿ����ϴ�");
					} else {
						JOptionPane.showMessageDialog(null,
								"�����ͺ��̽��� �������� ���߽��ϴ�!");
					}
				} else {
					JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�");
				}
			}
		} else if (obj == view.submitBtns[3]) {
			courseDao.close();
			view.close();
		} else if (obj == view.categoryBtns[0]) {
			// 0 ~ 4
			int menuNum = view.categoryBox.getSelectedIndex();
			String searchStr = view.categoryField.getText();
			if (searchStr == null || searchStr.equals("")) {
				JOptionPane.showMessageDialog(null, "�˻��׸��� �Է����ּ���!");
				view.categoryField.requestFocus();
				return;
			}

			if (menuNum != 0) {
				selectCategory(menuNum, searchStr);
			} else {
				JOptionPane.showMessageDialog(null, "�޴��� �����ϼ���!");
			}

		} else if (obj == view.categoryBtns[1]) {
			initSelect();
		}

		clear();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyTyped(KeyEvent e) {
		JTextField field = (JTextField) e.getSource();
		int limitLength = 0;
		if (field == view.inputFields[0] || field == view.inputFields[2]
				|| field == view.inputFields[3])
			limitLength = 10;
		else if (field == view.inputFields[1])
			limitLength = 20;

		if (field.getText().length() >= limitLength)
			e.consume();
	}
}
