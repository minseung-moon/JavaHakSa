package Professor;

public class ProfessorDTO {
	private String code;
	private String name;
	private String userId;
	private String address;
	private String mphone;
	private String hphone;
	private String ent_year;
	private String degree;
	private String major_code;
	private String roomno;
	
	public ProfessorDTO(String code, String name, String userId, String address, String mphone,
			String hphone, String ent_year, String degree, String major_code, String roomno) {
		super();
		this.code = code;
		this.name = name;
		this.userId = userId;
		this.address = address;
		this.mphone = mphone;
		this.hphone = hphone;
		this.ent_year = ent_year;
		this.degree = degree;
		this.major_code = major_code;
		this.roomno = roomno;
	}
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getMphone() {
		return mphone;
	}
	public void setMphone(String mphone) {
		this.mphone = mphone;
	}
	public String getHphone() {
		return hphone;
	}
	public void setHphone(String hphone) {
		this.hphone = hphone;
	}
	public String getEnt_year() {
		return ent_year;
	}
	public void setEnt_year(String ent_year) {
		this.ent_year = ent_year;
	}
	public String getDegree() {
		return degree;
	}
	public void setDegree(String degree) {
		this.degree = degree;
	}
	public String getMajor_code() {
		return major_code;
	}
	public void setMajor_code(String major_code) {
		this.major_code = major_code;
	}
	public String getRoomno() {
		return roomno;
	}
	public void setRoomno(String roomno) {
		this.roomno = roomno;
	}
	
	@Override
	public String toString() {
		return code+","+name+","+userId+","+address+","+mphone+","+hphone+","+ent_year+","+degree+","+major_code+","+roomno;
	}
	
	public String[] getArrays() {
		String[] returnArr = {code,name,userId,address,mphone,hphone,ent_year,degree,major_code,roomno}; 
		return returnArr;
	}
}
