package Major;

public class major {
		
		public static void main(String[] args) {
			new MajorView();
		}
}
