package Course;

public class CourseDTO {
	private String code;
	private String subject;
	private String year;
	private String major_code;
	private String grade;
	private String term;
	private String time;
	private String prof_code;
	private String credit;
	
	public CourseDTO(String code,String subject, String year, String major_code, String grade, String term, String time, String prof_code, String credit) {
		super();
		this.code = code;
		this.subject = subject;
		this.year = year;
		this.major_code = major_code;
		this.grade = grade;
		this.term = term;
		this.time = time;
		this.prof_code = prof_code;
		this.credit = credit;
	}
	
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMajor_code() {
		return major_code;
	}
	public void setMajor_code(String major_code) {
		this.major_code = major_code;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getTerm() {
		return term;
	}
	public void setTerm(String term) {
		this.term = term;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getProf_code() {
		return prof_code;
	}
	public void setProf_code(String prof_code) {
		this.prof_code = prof_code;
	}
	public String getCredit() {
		return credit;
	}
	public void setCredit(String credit) {
		this.credit = credit;
	}
	public Object[] getArrays() {
		Object[] returnArr = {code,subject, year, major_code, grade, term, time, prof_code, credit}; 
		return returnArr;
	}
	
	public Object[] getClassArrays() {
		Object[] returnArr = {code,subject, major_code, time, prof_code, credit}; 
		return returnArr;
	}
	
}
