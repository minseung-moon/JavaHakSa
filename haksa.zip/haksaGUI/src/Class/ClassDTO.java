package Class;

public class ClassDTO {
	private String std_code, prof_code, course_code, year;

	public String getStd_code() {
		return std_code;
	}

	public void setStd_code(String std_code) {
		this.std_code = std_code;
	}

	public String getProf_code() {
		return prof_code;
	}

	public void setProf_code(String prof_code) {
		this.prof_code = prof_code;
	}

	public String getCourse_code() {
		return course_code;
	}

	public void setCourse_code(String course_code) {
		this.course_code = course_code;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}
	
	
	
}
