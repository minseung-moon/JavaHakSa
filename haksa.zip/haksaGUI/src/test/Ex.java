package test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Ex{
	public static void main(String[] args) {
		
		System.out.println(datestr);
	}

}
