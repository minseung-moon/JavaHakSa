package Student;

import haksa.DBConn;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class StudentDAO {
	DBConn conn;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public StudentDAO() {
		conn = new DBConn();
		con = conn.conn;
	}

	public void close() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn.conn != null)
				con.close();
		} catch (Exception e) {
			System.out.println("���� ����");
		}
	}

	public ArrayList<StudentDTO> selectProfessor() {
		ArrayList<StudentDTO> allStudentDatas = new ArrayList<StudentDTO>();

		try {
			String sql = "select * from student";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				StudentDTO dto = new StudentDTO(rs.getString(1),
						rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getInt(7),
						rs.getString(8), rs.getInt(9), rs.getString(10),
						rs.getString(11));
				allStudentDatas.add(dto);
			}
		} catch (SQLException e) {
			System.out.println("Student�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allStudentDatas;
	}

	public boolean inserStudent(StudentDTO student) {
		boolean check = false;
		try {
			String sql = "insert into student values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, student.getCode());
			pstmt.setString(2, student.getName());
			pstmt.setString(3, student.getAddress());
			pstmt.setString(4, student.getUserId());
			pstmt.setString(5, student.getMphone());
			pstmt.setString(6, student.getHphone());
			pstmt.setInt(7, student.getEnt_year());
			pstmt.setString(8, student.getHighschool());
			pstmt.setInt(9, student.getEnd_year());
			pstmt.setString(10, student.getMajor());
			pstmt.setString(11, student.getProfessor());
			int num = pstmt.executeUpdate();

			if (num == 1)
				check = true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "�̹� �����ϴ� �л� �Դϴ�");
		}
		return check;
	}

	public boolean updateProfessor(StudentDTO student) {
		boolean check = false;

		try {
			String sql = "update student set name = ?, userId = ?, addr = ?, mphone = ?, hphone = ?,"
					+ " ent_year = ?, highschool = ?, end_year = ?, major = ?, professor = ? where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, student.getName());
			pstmt.setString(2, student.getUserId());
			pstmt.setString(3, student.getAddress());
			pstmt.setString(4, student.getMphone());
			pstmt.setString(5, student.getHphone());
			pstmt.setInt(6, student.getEnt_year());
			pstmt.setString(7, student.getHighschool());
			pstmt.setInt(8, student.getEnd_year());
			pstmt.setString(9, student.getMajor());
			pstmt.setString(10, student.getProfessor());
			pstmt.setString(11, student.getCode());
			int num = pstmt.executeUpdate();
			if (num == 1)
				check = true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "������ ���� �Ͽ����ϴ�");
		}
		return check;
	}

	public boolean deleteStudent(String code) {
		boolean check = false;

		try {
			String sql = "delete from student where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				check = true;
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "�������� �ʴ� �л� �Դϴ�!");
			e.printStackTrace();
		}
		return check;
	}

	public ArrayList<StudentDTO> selectCategory(int num, String searchStr) {
		ArrayList<StudentDTO> allStudentDatas = new ArrayList<StudentDTO>();
		String sql = "";
		try {
			if (num == 1) {
				sql = "select * from student where code = ?";
			} else if (num == 2) {
				sql = "select * from student where name = ?";
			} else if (num == 3) {
				sql = "select * from student where userId = ?";
			} else if (num == 4) {
				sql = "select * from student where address = ?";
			} else if (num == 5) {
				sql = "select * from student where mphone = ?";
			} else if (num == 6) {
				sql = "select * from student where hphone = ?";
			} else if (num == 7) {
				sql = "select * from student where ent_year = ?";
			} else if (num == 8) {
				sql = "select * from student where highschool = ?";
			} else if (num == 9) {
				sql = "select * from student where end_year = ?";
			} else if (num == 10) {
				sql = "select * from student where major = ?";
			} else if (num == 11) {
				sql = "select * from student where professor = ?";
			}

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, searchStr);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				StudentDTO dto = new StudentDTO(rs.getString(1),
						rs.getString(2), rs.getString(3), rs.getString(4),
						rs.getString(5), rs.getString(6), rs.getInt(7),
						rs.getString(8), rs.getInt(9), rs.getString(10),
						rs.getString(11));
				allStudentDatas.add(dto);
			}
		} catch (SQLException e) {
			System.out.println(searchStr + "�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allStudentDatas;
	}

}
