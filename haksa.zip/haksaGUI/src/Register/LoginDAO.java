package Register;

import haksa.DBConn;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

public class LoginDAO {
	DBConn conn;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public LoginDAO() {
		conn = new DBConn();
		con = conn.conn;
	}

	public void close() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn.conn != null)
				con.close();
		} catch (Exception e) {
			System.out.println("���� ����");
		}
	}

	public LoginDTO Logining(String id, String password) {
		String sql = "select password, owner, auth, date  from admin where id = ?";
		boolean result = false;
		LoginDTO loginDTO = null;
		String owner, auth, date;
		try {
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			rs.next();
			owner = rs.getString(2);
			auth = rs.getString(3);
			date = rs.getString(4);
			if (password.equals(rs.getString(1))) {
				result = true;
			}
			if (!result) {
				JOptionPane.showMessageDialog(null, "��й�ȣ�� Ʋ�Ƚ��ϴ�");
				return loginDTO;
			}
			loginDTO = new LoginDTO(id, password, owner, auth, date);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "���� ����� �Դϴ�");
		}
		return loginDTO;
	}

	public String getName(String owner, String auth) {
		String sql, name = null;
		try {
			if (auth.equals("p")) {
				sql = "select name from professor where code = ?";
				
			} else {
				sql = "select name from student where code = ?";
			}
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, owner);
			rs = pstmt.executeQuery();
			rs.next();
			name = rs.getString(1);
		} catch (Exception e) {
			JOptionPane.showMessageDialog(null, "�̸��� �������� ���߽��ϴ�");
		}
		return name;

	}
}
