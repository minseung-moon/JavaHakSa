package Register;

public class LoginDTO {
	private String id;
	private String password;
	private String owner;
	private String auth;
	private String date;
	
	public LoginDTO(String id, String password, String owner, String auth, String date) {
		super();
		this.id = id;
		this.password = password;
		this.owner = owner;
		this.auth = auth;
		this.date = date;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(String owner) {
		this.owner = owner;
	}

	public String getAuth() {
		return auth;
	}

	public void setAuth(String auth) {
		this.auth = auth;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}
	
	public Object[] getArrays() {
		Object[] returnArr = {id, password, owner, auth, date}; 
		return returnArr;
	}
}