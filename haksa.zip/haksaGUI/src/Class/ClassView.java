package Class;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import Class.ClassBtnAction;
import Register.LoginDTO;

public class ClassView extends JFrame{
	
	private static final long serialVersionUID = 1L;
	JPanel[] mainPanels = new JPanel[3];
	JPanel[] formPanels = new JPanel[3];
	JPanel[] inputPanels = new JPanel[3];
	JLabel titleLabel;
	String[] inputLabelStr = { "�л��ڵ�", "�̸�", "�к�/����"};
	JLabel[] inputLabels = new JLabel[inputLabelStr.length];
	JTextField[] inputFields = new JTextField[4];
	JComboBox<String> authBox;
//	JTextField categoryField;
	JComboBox<String> categoryBox;
	String[] categoryBtnStr = { "��ȸ", "��ü ��ȸ" };
	JButton[] categoryBtns = new JButton[categoryBtnStr.length];
	String[] submitBtnStr = {"����", "����" };
	JButton[] submitBtns = new JButton[submitBtnStr.length];
	JScrollPane[] scrollPanes = new JScrollPane[2];
	JTable[] tables = new JTable[2];
	DefaultTableModel[] dtms = new DefaultTableModel[2];
	LoginDTO loginDTO;
	String username;
	
	public ClassView(LoginDTO loginDTO, String username) {
		this.loginDTO = loginDTO;
		this.username = username;
		this.setTitle("���� ��û"+loginDTO.getOwner() + " "+username);
		this.setSize(610, 700);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setResizable(false);

		for (int i = 0; i < mainPanels.length; i++) {
			mainPanels[i] = new JPanel();
			formPanels[i] = new JPanel();
		}
		for (int i = 0; i < inputPanels.length; i++) {
			inputPanels[i] = new JPanel();
		}
		titleLabel = new JLabel("���� ��û");
		for (int i = 0; i < inputLabels.length; i++) {
			inputLabels[i] = new JLabel(inputLabelStr[i]);
		}
		for (int i = 0; i < inputFields.length; i++) {
			inputFields[i] = new JTextField(10);
			inputFields[i].setEnabled(false);
		}
//		categoryField = new JTextField(10);
		authBox = new JComboBox<String>();
		categoryBox = new JComboBox<String>();
		for (int i = 0; i < categoryBtns.length; i++) {
			categoryBtns[i] = new JButton(categoryBtnStr[i]);
		}
		for (int i = 0; i < submitBtns.length; i++) {
			submitBtns[i] = new JButton(submitBtnStr[i]);
		}

		titleLabel.setFont(new Font("����", Font.BOLD, 23));
		titleLabel.setForeground(Color.WHITE);
		mainPanels[0].add(titleLabel);
		mainPanels[0].setBackground(Color.BLACK);
		this.add(mainPanels[0], BorderLayout.NORTH);

		
		authBox.addItem("����� ����");
		authBox.addItem("p");
		authBox.addItem("s");
		
		formPanels[0].setPreferredSize(new Dimension(600, 100));
		for (int i = 0; i < inputPanels.length; i++) {
			inputPanels[i].add(inputLabels[i]);
			inputPanels[i].add(inputFields[i]);
		}
		for (JPanel panel : inputPanels) {
			formPanels[0].add(panel);
		}
		inputFields[0].setText(loginDTO.getOwner());
		inputFields[1].setText(username);
		
		String[] categoryItems = {  "�������ڵ�", "�������", "��������", "�����ü�", "��米��", "����" };
		categoryBox.addItem("�˻��� ī�װ����� ����");

		formPanels[1].add(categoryBox);
		for (JButton btn : categoryBtns) {
			btn.setBackground(Color.GREEN);
			btn.setForeground(Color.RED);
			formPanels[1].add(btn);
		}
		formPanels[1].setBackground(Color.BLUE);
		// table
		String[][] courseTableDatas = {};
		String[][] classTableDatas = {};
		dtms[0] = new DefaultTableModel(courseTableDatas, categoryItems);
		dtms[1] = new DefaultTableModel(classTableDatas, categoryItems);
		tables[0] = new JTable(dtms[0]);
		tables[1] = new JTable(dtms[1]);
		scrollPanes[0] = new JScrollPane(tables[0]);
		scrollPanes[1] = new JScrollPane(tables[1]);
		scrollPanes[0].setPreferredSize(new Dimension(200, 200));
		scrollPanes[1].setPreferredSize(new Dimension(200, 200));
		formPanels[2].setLayout(new GridLayout(2,1));
		formPanels[2].add(scrollPanes[0]);
		formPanels[2].add(scrollPanes[1]);

		mainPanels[1].setLayout(new BorderLayout());
		mainPanels[1].add(formPanels[0], BorderLayout.NORTH);
		mainPanels[1].add(formPanels[1], BorderLayout.CENTER);
		mainPanels[1].add(formPanels[2], BorderLayout.SOUTH);
		this.add(mainPanels[1], BorderLayout.CENTER);

		submitBtns[0].setBackground(Color.GREEN);
		submitBtns[1].setBackground(Color.PINK);
		submitBtns[0].setForeground(Color.RED);
		submitBtns[1].setForeground(Color.WHITE);

		for (JButton btn : submitBtns) {
			btn.setPreferredSize(new Dimension(140, 50));
			mainPanels[2].add(btn);
		}
		
		this.add(mainPanels[2], BorderLayout.SOUTH);
		new ClassBtnAction(this);
		this.setVisible(true);
	}
	public void close() {
		this.dispose();
	}
//	public static void main(String[] args) {
//		new ClassView();
//	}
}
