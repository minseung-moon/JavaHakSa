package Student;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class StudentBtnAction extends MouseAdapter implements ActionListener,
		KeyListener {
	private StudentView view;
	private StudentDAO dao;
	private StudentDTO studentDTO = new StudentDTO(null, null, null,
			null, null, null, 0, null, 0, null, null);
	private int rowIndex = -1;
	private JTable table;
	ArrayList<StudentDTO> selectAll;

	public StudentBtnAction(StudentView view) {
		super();
		this.view = view;
		view.BtnAddAction(this);
		view.MouseAddAction(this);
		view.KeyAddAction(this);
		table = view.table;
		dao = new StudentDAO();
		initSelect();
	}

	private void initSelect() {
		// ���̺��� �⺻ ������ ���
		view.dtm.setRowCount(0);
		selectAll = dao.selectProfessor();
		for (StudentDTO select : selectAll) {
			view.dtm.addRow(select.getArrays());
		}
	}

	public void clear() {
		view.code.setText("");
		view.code.setEnabled(true);
		view.name.setText("");
		view.userId1.setText("");
		view.userId2.setText("");
		view.address.setText("");
		view.mphone.setText("");
		view.hphone.setText("");
		view.ent_year.setText("");
		view.highschool.setText("");
		view.end_year.setText("");
		view.major.setText("");
		view.professor.setText("");
		view.tsearch.setText("");
		rowIndex = -1;
	}

	private boolean checkInput() {
		boolean check = false;
		if (view.code.getText() == null || view.code.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ڵ带 �Է����ּ���");
			view.code.requestFocus();
		} else if (view.name.getText() == null
				|| view.name.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "������ �Է����ּ���");
			view.name.requestFocus();
		} else if (view.userId1.getText() == null
				|| view.userId1.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ֹι�ȣ ���ڸ��� �Է����ּ���");
			view.userId1.requestFocus();
		} else if (view.userId2.getText() == null
				|| view.userId2.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ֹι�ȣ ���ڸ��� �Է����ּ���");
			view.userId2.requestFocus();
		} else if (view.address.getText() == null
				|| view.address.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ּҸ� �Է����ּ���");
			view.address.requestFocus();
		} else if (view.mphone.getText() == null
				|| view.mphone.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�޴��ȣ�� �Է����ּ���");
			view.mphone.requestFocus();
		} else if (view.hphone.getText() == null
				|| view.hphone.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "��ȭ��ȣ�� �Է����ּ���");
			view.hphone.requestFocus();
		} else if (view.ent_year.getText() == null
				|| view.ent_year.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ӿ뿬���� �Է����ּ���");
			view.ent_year.requestFocus();
		} else if (view.highschool.getText() == null
				|| view.highschool.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "������ �Է����ּ���");
			view.highschool.requestFocus();
		} else if (view.end_year.getText() == null
				|| view.end_year.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�а�/������ �Է����ּ���");
			view.end_year.requestFocus();
		} else if (view.major.getText() == null
				|| view.major.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�������� �Է����ּ���");
			view.major.requestFocus();
		} else if (view.professor.getText() == null
				|| view.professor.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�������� �Է����ּ���");
			view.professor.requestFocus();
		} else {
			check = true;
			studentDTO = new StudentDTO(view.code.getText(),
					view.name.getText(), view.userId1.getText() + "-"
							+ view.userId2.getText(), view.address.getText(),
					view.mphone.getText(), view.hphone.getText(),
					Integer.parseInt(view.ent_year.getText()), view.highschool.getText(),
					Integer.parseInt(view.end_year.getText()), view.major.getText(),
					view.professor.getText());
		}
		return check;
	}

	private void selectCategory(int num, String searchStr) {
		// ���̺��� �⺻ ������ ���
		view.dtm.setRowCount(0);
		selectAll = dao.selectCategory(num, searchStr);
		for (StudentDTO select : selectAll) {
			String[] major = select.toString().split(",");
			view.dtm.addRow(major);
		}
	}

	private void updateTable(int rowIndex) {
		table.setValueAt(studentDTO.getCode(), rowIndex, 0);
		table.setValueAt(studentDTO.getName(), rowIndex, 1);
		table.setValueAt(studentDTO.getAddress(), rowIndex, 2);
		table.setValueAt(studentDTO.getUserId(), rowIndex, 3);
		table.setValueAt(studentDTO.getMphone(), rowIndex, 4);
		table.setValueAt(studentDTO.getHphone(), rowIndex, 5);
		table.setValueAt(studentDTO.getEnt_year(), rowIndex, 6);
		table.setValueAt(studentDTO.getHighschool(), rowIndex, 7);
		table.setValueAt(studentDTO.getEnd_year(), rowIndex, 8);
		table.setValueAt(studentDTO.getMajor(), rowIndex, 9);
		table.setValueAt(studentDTO.getProfessor(), rowIndex, 10);
		JOptionPane.showMessageDialog(null, "���� �Ǿ����ϴ�");
	}

	public void mouseClicked(MouseEvent e) {
		rowIndex = table.getSelectedRow();
		if (rowIndex == -1 || e.getSource() != table) {
			clear();
			return;
		}
		studentDTO.setCode(table.getValueAt(rowIndex, 0).toString());
		studentDTO.setName(table.getValueAt(rowIndex, 1).toString());
		studentDTO.setAddress(table.getValueAt(rowIndex, 2).toString());
		studentDTO.setUserId(table.getValueAt(rowIndex, 3).toString());
		studentDTO.setMphone(table.getValueAt(rowIndex, 4).toString());
		studentDTO.setHphone(table.getValueAt(rowIndex, 5).toString());
		studentDTO.setEnt_year(Integer.parseInt(table.getValueAt(rowIndex, 6).toString()));
		studentDTO.setHighschool(table.getValueAt(rowIndex, 7).toString());
		studentDTO.setEnd_year(Integer.parseInt(table.getValueAt(rowIndex, 8).toString()));
		studentDTO.setMajor(table.getValueAt(rowIndex, 9).toString());
		studentDTO.setProfessor(table.getValueAt(rowIndex, 10).toString());
		view.code.setText(studentDTO.getCode());
		view.code.setEnabled(false);
		view.name.setText(studentDTO.getName());
		String[] userIdArr = studentDTO.getUserId().split("-");
		view.userId1.setText(userIdArr[0]);
		view.userId2.setText(userIdArr[1]);
		view.address.setText(studentDTO.getAddress());
		view.mphone.setText(studentDTO.getMphone());
		view.hphone.setText(studentDTO.getHphone());
		view.ent_year.setText(Integer.toString(studentDTO.getEnt_year()));
		view.highschool.setText(studentDTO.getHighschool());
		view.end_year.setText(Integer.toString(studentDTO.getEnd_year()));
		view.major.setText(studentDTO.getMajor());
		view.professor.setText(studentDTO.getProfessor());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		if (obj == view.input) {
			if (!checkInput())
				return;

			int confirm = JOptionPane.showConfirmDialog(null, "���� "
					+ studentDTO.getCode() + "�� �߰��Ͻðڽ��ϱ�?", "�а��߰�",
					JOptionPane.OK_CANCEL_OPTION);
			if (confirm != 0) {
				JOptionPane.showMessageDialog(null, "�а��߰��� ����ϼ̽��ϴ�");
				return;
			}
			if (dao.inserStudent(studentDTO)) {
				System.out.println(1);
				JOptionPane.showMessageDialog(null, "���忡 �����ϼ̽��ϴ�");
				view.dtm.addRow(studentDTO.getArrays());
			} else
				JOptionPane.showMessageDialog(null, "���忡 �����ϼ̽��ϴ�!");
		} else if (obj == view.edit) {
			if (!checkInput())
				return;
			int check = JOptionPane.showConfirmDialog(null,
					studentDTO.getCode() + "�� ���� �Ͻðڽ��ϱ�?", "���� ����",
					JOptionPane.YES_NO_OPTION);

			if (check == 1) {
				JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�");
				return;
			} else {
				if (rowIndex != -1 && dao.updateProfessor(studentDTO)) {
					updateTable(rowIndex);
				} else if (rowIndex == -1 && dao.updateProfessor(studentDTO)) {
					for (int i = 0; i < view.table.getRowCount(); i++) {
						if (table.getValueAt(i, 0).toString()
								.equals(studentDTO.getCode())) {
							rowIndex = i;
							break;
						}
					}
					updateTable(rowIndex);
				} else
					JOptionPane.showMessageDialog(null, "�����ͺ��̽� ������ �����Ͽ����ϴ�!");
			}
		} else if (obj == view.delte) {
			rowIndex = table.getSelectedRow();
			if (rowIndex == -1) {
				JOptionPane.showMessageDialog(null, "������ ���� �������ּ���!");
				return;
			} else {
				String code = table.getValueAt(rowIndex, 0).toString();
				int check = JOptionPane.showConfirmDialog(null, code
						+ "�� ���� �����Ͻðڽ��ϱ�?", "���� ����", JOptionPane.YES_NO_OPTION);
				if (check == 0) {
					if (dao.deleteStudent(code)) {
						view.dtm.removeRow(rowIndex);
						JOptionPane.showMessageDialog(null, "���� �Ǿ����ϴ�");
					} else {
						JOptionPane.showMessageDialog(null,
								"�����ͺ��̽��� �������� ���߽��ϴ�!");
					}
				} else {
					JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�");
				}
			}
		} else if (obj == view.exit) {
			dao.close();
			view.close();
		} else if (obj == view.bsearch) {
			// 0 ~ 4
			int menuNum = view.search.getSelectedIndex();
			String searchStr = view.tsearch.getText();
			if (searchStr == null || searchStr.equals("")) {
				JOptionPane.showMessageDialog(null, "�˻��׸��� �Է����ּ���!");
				view.tsearch.requestFocus();
				return;
			}

			if (menuNum != 0) {
				selectCategory(menuNum, searchStr);
			} else {
				JOptionPane.showMessageDialog(null, "�޴��� �����ϼ���!");
			}

		} else if (obj == view.tbsearch) {
			initSelect();
		}

		clear();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyTyped(KeyEvent e) {
		JTextField field = (JTextField) e.getSource();
		int limitLength = 0;
		if (field == view.code || field == view.name
				|| field == view.major || field == view.professor)
			limitLength = 10;
		else if (field == view.mphone || field == view.hphone)
			limitLength = 15;
		else if (field == view.address)
			limitLength = 45;
		else if (field == view.highschool)
			limitLength = 20;
		else if (field == view.userId1)
			limitLength = 6;
		else if (field == view.userId2)
			limitLength = 7;
		else if (field == view.end_year || field == view.ent_year)
			limitLength = 4;

		if (field.getText().length() >= limitLength)
			e.consume();
	}

}
