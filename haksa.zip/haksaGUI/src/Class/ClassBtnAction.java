package Class;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import Class.ClassView;
import Course.CourseDTO;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class ClassBtnAction extends MouseAdapter implements ActionListener {
	
	private ClassView view;
	ClassDAO classDAO;
	ClassDTO classDTO = new ClassDTO();
	private int rowIndex = -1;
	private JTable[] tables = new JTable[2];
	ArrayList<CourseDTO> selectAll;
	
	public ClassBtnAction(ClassView view) {
		super();
		this.view = view;
		classDAO = new ClassDAO();
		tables[1] = view.tables[1];
		ArrayList<String> majorCode = classDAO.selectMajorCodes();
		majorCode.forEach(item -> {
			view.categoryBox.addItem(item);
		});
		initSelect();
		view.categoryBtns[0].addActionListener(this);
		view.categoryBtns[1].addActionListener(this);
		view.submitBtns[0].addActionListener(this);
		view.submitBtns[1].addActionListener(this);
		view.addMouseListener(this);
//		tables[0].addMouseListener(this);
		view.inputFields[2].setText(classDAO.getDepartment(view.loginDTO.getOwner()));
	}
	
	private void initSelect() {
		// ���̺��� �⺻ ������ ���
		view.dtms[0].setRowCount(0);
		selectAll = classDAO.selectClass();
		for (CourseDTO select : selectAll) {
			view.dtms[0].addRow(select.getClassArrays());
		}
	}
	
	public void clear() {
		for (JTextField field : view.inputFields) {
			field.setText("");
		}
		view.categoryBox.setSelectedIndex(0);
		rowIndex = -1;
	}
	
	private void selectCategory(String categoryItem) {
		// ���̺��� �⺻ ������ ���
		view.dtms[0].setRowCount(0);
		selectAll = classDAO.selectCategory(categoryItem);
		for (CourseDTO select : selectAll) {
			view.dtms[0].addRow(select.getClassArrays());
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

//		if (obj == view.submitBtns[0]) {
//			if (!checkInput())
//				return;
//
//			int confirm = JOptionPane.showConfirmDialog(null,
//					"����" + courseDto.getCode() + "�� �߰��Ͻðڽ��ϱ�?", "�а��߰�",
//					JOptionPane.OK_CANCEL_OPTION);
//			if (confirm != 0) {
//				JOptionPane.showMessageDialog(null, "�а��߰��� ����ϼ̽��ϴ�");
//				return;
//			}
//
//			if (courseDao.inserCourse(courseDto)) {
//				System.out.println(1);
//				JOptionPane.showMessageDialog(null, "���忡 �����ϼ̽��ϴ�");
//				view.dtm.addRow(courseDto.getArrays());
//			} else
//				JOptionPane.showMessageDialog(null, "���忡 �����ϼ̽��ϴ�!");
//		} else if (obj == view.submitBtns[1]) {
//			if (!checkInput())
//				return;
//
//			int check = JOptionPane.showConfirmDialog(null, courseDto.getCode()
//					+ "�� ���� �Ͻðڽ��ϱ�?", "���� ����", JOptionPane.YES_NO_OPTION);
//
//			if (check == 1) {
//				JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�");
//				return;
//			} else {
//				if (rowIndex != -1 && courseDao.updateCourse(courseDto)) {
//					updateTable(rowIndex);
//				} else if (rowIndex == -1 && courseDao.updateCourse(courseDto)) {
//					for (int i = 0; i < view.table.getRowCount(); i++) {
//						if (table.getValueAt(i, 0).toString()
//								.equals(courseDto.getCode())) {
//							rowIndex = i;
//							break;
//						}
//					}
//					updateTable(rowIndex);
//				} else
//					JOptionPane.showMessageDialog(null, "�����ͺ��̽� ������ �����Ͽ����ϴ�!");
//			}
//		} else if (obj == view.submitBtns[2]) {
//			rowIndex = table.getSelectedRow();
//			if (rowIndex == -1) {
//				JOptionPane.showMessageDialog(null, "������ ���� �������ּ���!");
//				return;
//			} else {
//				String code = table.getValueAt(rowIndex, 0).toString();
//				int check = JOptionPane.showConfirmDialog(null, code
//						+ "�� ���� �����Ͻðڽ��ϱ�?", "���� ����", JOptionPane.YES_NO_OPTION);
//				if (check == 0) {
//					if (courseDao.deleteCourse(code)) {
//						view.dtm.removeRow(rowIndex);
//						JOptionPane.showMessageDialog(null, "���� �Ǿ����ϴ�");
//					} else {
//						JOptionPane.showMessageDialog(null,
//								"�����ͺ��̽��� �������� ���߽��ϴ�!");
//					}
//				} else {
//					JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�");
//				}
//			}
//		} else if (obj == view.submitBtns[3]) {
//			courseDao.close();
//			view.close();
//		} else if (obj == view.categoryBtns[0]) {
//			// 0 ~ 4
//			int menuNum = view.categoryBox.getSelectedIndex();
//			String searchStr = view.categoryField.getText();
//			if (searchStr == null || searchStr.equals("")) {
//				JOptionPane.showMessageDialog(null, "�˻��׸��� �Է����ּ���!");
//				view.categoryField.requestFocus();
//				return;
//			}
//
//			if (menuNum != 0) {
//				selectCategory(menuNum, searchStr);
//			} else {
//				JOptionPane.showMessageDialog(null, "�޴��� �����ϼ���!");
//			}
//
//		} else if (obj == view.categoryBtns[1]) {
//			initSelect();
//		}
		
		if (obj == view.categoryBtns[0]) {
			// 0 ~ 4
			int menuNum = view.categoryBox.getSelectedIndex();
			if (menuNum != 0) {
				String categoryItem = (String)view.categoryBox.getSelectedItem();
				selectCategory(categoryItem);
			} else {
				JOptionPane.showMessageDialog(null, "�޴��� �����ϼ���!");
			}

		} else if (obj == view.categoryBtns[1]) {
			initSelect();
		} else if (obj == view.submitBtns[1]) {
			classDAO.close();
			view.close();
		}

	}
	public void mouseClicked(MouseEvent e) {
		rowIndex = tables[0].getSelectedRow();
		if (rowIndex == -1 || e.getSource() != tables[0]) {
			clear();
			return;
		}
//		courseDto.setCode(table.getValueAt(rowIndex, 0).toString());
//		courseDto.setSubject(table.getValueAt(rowIndex, 1).toString());
//		courseDto.setMajor_code(table.getValueAt(rowIndex, 2).toString());
//		courseDto.setYear(table.getValueAt(rowIndex, 3).toString());
//		courseDto.setGrade(table.getValueAt(rowIndex, 4).toString());
//		courseDto.setTerm(table.getValueAt(rowIndex, 5).toString());
//		courseDto.setTime(table.getValueAt(rowIndex, 6).toString());
//		courseDto.setProf_code(table.getValueAt(rowIndex, 7).toString());
//		courseDto.setCredit(table.getValueAt(rowIndex, 8).toString());
//		view.inputFields[0].setText(courseDto.getCode());
//		view.inputFields[1].setText(courseDto.getSubject());
//		view.inputFields[2].setText(courseDto.getTime());
//		view.inputFields[3].setText(courseDto.getCredit());
//		view.inputBoxs[0].setSelectedItem(courseDto.getYear());
//		view.inputBoxs[1].setSelectedItem(courseDto.getMajor_code());
//		view.inputBoxs[2].setSelectedItem(courseDto.getGrade());
//		view.inputBoxs[3].setSelectedItem(courseDto.getTerm());
//		view.inputBoxs[4].setSelectedItem(courseDto.getProf_code());
	}
}
