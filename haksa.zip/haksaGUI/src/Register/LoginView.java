package Register;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LoginView extends JDialog{
	
	private static final long serialVersionUID = 1L;
	
	JPanel[] layoutPanels = new JPanel[3];
	JPanel[] inputPanels = new JPanel[3];
	JLabel titleLabel;
	String[] inputStr = {"���̵�", "�н�����", "������̸�"};
	JLabel[] inputLabels = new JLabel[inputStr.length];
	JTextField[] inputFields = new JTextField[inputLabels.length];
	JButton confirmBtn;
	
	public LoginView() {
		this.setSize(400, 300);
		this.setTitle("�α���");
		this.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		this.setLayout(new BorderLayout());
		
		// ������Ʈ ����
		for(int i = 0; i < layoutPanels.length; i++) {
			layoutPanels[i] = new JPanel();
			inputPanels[i] = new JPanel();
			inputLabels[i] = new JLabel(inputStr[i]);
			inputFields[i] = new JTextField(15);
			inputPanels[i].add(inputLabels[i]);
			inputPanels[i].add(inputFields[i]);
		}
		for(JPanel inputPanel : inputPanels) {
			layoutPanels[1].add(inputPanel);	
		}
		titleLabel = new JLabel("�α���");
		layoutPanels[0].add(titleLabel);
		confirmBtn = new JButton("Ȯ��");
		layoutPanels[2].add(confirmBtn);

		// �ɼ� �� ��Ÿ�ϸ�
		layoutPanels[0].setBackground(Color.BLACK);
		titleLabel.setForeground(Color.WHITE);
		titleLabel.setFont(new Font("serif", Font.BOLD, 20));
		inputFields[2].setEnabled(false);
		layoutPanels[2].setBackground(Color.BLUE);
		confirmBtn.setBackground(Color.GREEN);
		confirmBtn.setForeground(Color.RED);
		
		this.add(layoutPanels[0],BorderLayout.NORTH);
		this.add(layoutPanels[1],BorderLayout.CENTER);
		this.add(layoutPanels[2],BorderLayout.SOUTH);
		
		// �׼� �߰�
		new LoginAction(this); 
		
		this.setVisible(true);
	}
	
	public void addActionEvent(ActionListener listener) {
		confirmBtn.addActionListener(listener);
	}
	
	public static void main(String[] args) {
		new LoginView();
	}
	
}
