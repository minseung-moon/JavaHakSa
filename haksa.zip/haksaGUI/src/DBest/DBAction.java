package DBest;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class DBAction {
	DBConn connector;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public DBAction() {
		connector = new DBConn();
	}
	
	public ArrayList<User> selectDate() {
		ArrayList<User> allRowDatas = new ArrayList<User>();
		try{
			String sql = "select * from custmer";
			pstmt = connector.conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String name = rs.getString(1);
				String grade = rs.getString(2);
				Integer age = rs.getInt(3);
				String job = rs.getString(4);
				
				User user = new User(name, grade, age, job);
				allRowDatas.add(user);
			}
		}catch(SQLException e){
			e.printStackTrace();
		}
		return allRowDatas;
	}
	
//	public void selectDate(String name) {
//		try{
//			String sql = "select * from custmer where name = ?";
//			pstmt = connector.conn.prepareStatement(sql);
//			pstmt.setString(1, name);
//			rs = pstmt.executeQuery();
//			int i = 0;
//			while(rs.next()) {
//				String uname = rs.getString(1);
//				String ugrade = rs.getString(2);
//				Integer uage = rs.getInt(3);
//				String ujob = rs.getString(4);
//				
//				Object[] rowData = { uname, ugrade, uage, ujob };
//				dtm.addRow(rowData);
//			}
//		}catch(SQLException e){
//			e.printStackTrace();
//		}
//	}
	
	
	public boolean insertDate(String name, String grade, int age, String job) {
		boolean result = false;
		try{
			String sql = "insert into custmer values(?, ?, ?, ?)";
			pstmt = connector.conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, grade);
			pstmt.setInt(3, age);
			pstmt.setString(4, job);
			int i = pstmt.executeUpdate();
			
			if(i == 1) result = true;
		}catch(SQLException e){
			JOptionPane.showMessageDialog(null, "�̵̹�ϵ� ȸ�� �Դϴ�!");
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean updateDate(String name, String grade, int age, String job) {
		boolean result = false;
		try{
			String sql = "update custmer set grade = ?, age = ?, job = ?  where name = ?";
			pstmt = connector.conn.prepareStatement(sql);
			pstmt.setString(1, grade);
			pstmt.setInt(2, age);
			pstmt.setString(3, job);
			pstmt.setString(4, name);
			int i = pstmt.executeUpdate();
			
			if(i == 1) result = true;
		}catch(SQLException e){
			JOptionPane.showMessageDialog(null, "�̹� �����ϴ� ������ �Դϴ�");
			e.printStackTrace();
		}
		return result;
	}
	
	public boolean deleteDate(String name) {
		boolean result = false;
		try{
			
			String sql = "delete from custmer where name = ?";
			pstmt = connector.conn.prepareStatement(sql);
			pstmt.setString(1, name);
			int i = pstmt.executeUpdate();
			if(i == 1) {
				result = true;
			}
		}catch(SQLException e){
			JOptionPane.showMessageDialog(null, "�������� �ʴ� ȸ�� �Դϴ�!");
			e.printStackTrace();
		}
		return result;
	}
	
	public void closeDB() {
		try {
			if(rs != null) rs.close();	
			if(pstmt != null) pstmt.close();
			if(connector.conn != null) connector.conn.close();
		} catch (SQLException e) {
			
		}
		
	}
}
