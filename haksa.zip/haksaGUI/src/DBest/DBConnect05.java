package DBest;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
public class DBConnect05 {
	DBConn connector;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public void addBook(String name, String grade, int age, String job) {
		try {
			String sql = "insert into custmer(name, grade, age, job) values (?, ?, ?, ?)";
			pstmt = connector.conn.prepareStatement(sql);
			pstmt.setString(1, name);
			pstmt.setString(2, grade);
			pstmt.setInt(3, age);
			pstmt.setString(4, job);
			int i = pstmt.executeUpdate(); // 1, ����, 0 ����
			
			if(i == 1)
				System.out.println("���ڵ� �߰� ����");
			else
				System.out.println("���ڵ� �߰� ����");
			if(rs != null)
				rs.close();
			if(pstmt != null)
				pstmt.close();
			if(connector.conn != null)
				connector.conn.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			System.exit(0);
		}
	}
	
	public DBConnect05(){
		connector = new DBConn();		
	}
	
	public static void main(String[] args) throws SQLException{
		DBConnect05 connect05 = new DBConnect05();
		connect05.addBook("a", "Vip", 30, "����");
	}
}
