package DBest;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class FrameHanler implements ActionListener{
	
	public FrameHanler() {
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		
		
	}
}
