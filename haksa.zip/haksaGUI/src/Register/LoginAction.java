package Register;

import haksa.HaksaMenu;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class LoginAction implements ActionListener {

	LoginView login;
	JTextField[] inputFields;
	LoginDAO loginDAO;
	LoginDTO loginDTO;

	public LoginAction(LoginView login) {
		this.login = login;
		login.addActionEvent(this);
		inputFields = login.inputFields;
		loginDAO = new LoginDAO();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String id = inputFields[0].getText();
		String password = inputFields[1].getText();
		String name = inputFields[2].getText();
		if(name == null || name.equals("")) {
			if (id == null || id.equals("")) {
				JOptionPane.showMessageDialog(null, "���̵� �Է����ּ���");
				inputFields[0].requestFocus();
				return;
			} else if (password == null || password.equals("")) {
				JOptionPane.showMessageDialog(null, "��й�ȣ�� �Է����ּ���");
				inputFields[1].requestFocus();
				return;
			}

			loginDTO = loginDAO.Logining(id, password);
			if(loginDTO != null) {
				name = loginDAO.getName(loginDTO.getOwner(), loginDTO.getAuth());
				JOptionPane.showMessageDialog(null,name+(loginDTO.getAuth().equals("p")?"������":"�л���")+" ���������� ���� �Ǿ����ϴ�");
				inputFields[2].setText(name);
			}			
		} else {
			// Ȯ�� = 0, ���, x = 2, -1
			int result = JOptionPane.showConfirmDialog(null, name+"������ �����Ͻðڽ��ϱ�?","���� Ȯ��", JOptionPane.OK_CANCEL_OPTION);
			if(result == 0) {
				login.dispose();
				new HaksaMenu(loginDTO, name);
			}
			
		}

	}
}
