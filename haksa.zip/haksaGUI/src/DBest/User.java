package DBest;

public class User {
	private String name;
	private String grade;
	private int age;
	private String job;
	
	public User(String name, String grade, int age, String job) {
		super();
		this.name = name;
		this.grade = grade;
		this.age = age;
		this.job = job;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}
	
	@Override
	public String toString() {
		return name+","+grade+","+age+","+job;
	}
}
