package Student;

public class StudentDTO {
	private String code;
	private String name;
	private String address;
	private String userId;
	private String mphone;
	private String hphone;
	private int ent_year; 
	private String highschool;
	private int end_year;
	private String major;
	private String professor;
	
	public StudentDTO(String code, String name, String userId, String address, String mphone,
			String hphone, int ent_year, String highschool, int end_year, String major, String professor) {
		super();
		this.code = code;
		this.name = name;
		this.userId = userId;
		this.address = address;
		this.mphone = mphone;
		this.hphone = hphone;
		this.ent_year = ent_year;
		this.highschool = highschool;
		this.end_year = end_year;
		this.major = major;
		this.professor = professor;
	}
	
	
	
	public String getCode() {
		return code;
	}



	public void setCode(String code) {
		this.code = code;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getAddress() {
		return address;
	}



	public void setAddress(String address) {
		this.address = address;
	}



	public String getUserId() {
		return userId;
	}



	public void setUserId(String userId) {
		this.userId = userId;
	}



	public String getMphone() {
		return mphone;
	}



	public void setMphone(String mphone) {
		this.mphone = mphone;
	}



	public String getHphone() {
		return hphone;
	}



	public void setHphone(String hphone) {
		this.hphone = hphone;
	}



	public int getEnt_year() {
		return ent_year;
	}



	public void setEnt_year(int ent_year) {
		this.ent_year = ent_year;
	}



	public String getHighschool() {
		return highschool;
	}



	public void setHighschool(String highschool) {
		this.highschool = highschool;
	}



	public int getEnd_year() {
		return end_year;
	}



	public void setEnd_year(int end_year) {
		this.end_year = end_year;
	}



	public String getMajor() {
		return major;
	}



	public void setMajor(String major) {
		this.major = major;
	}



	public String getProfessor() {
		return professor;
	}



	public void setProfessor(String professor) {
		this.professor = professor;
	}



	public Object[] getArrays() {
		Object[] returnArr = {code,name,userId,address,mphone,hphone,ent_year,highschool,end_year,major, professor}; 
		return returnArr;
	}
}
