package Class;

import haksa.DBConn;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import Course.CourseDTO;

public class ClassDAO {
	
	DBConn conn;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public ClassDAO() {
		conn = new DBConn();
		con = conn.conn;
	}
	
	public void close() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn.conn != null)
				con.close();
		} catch (Exception e) {
			System.out.println("���� ����");
		}
	}
	
	public ArrayList<CourseDTO> selectClass() {
		ArrayList<CourseDTO> allCourseDatas = new ArrayList<CourseDTO>();

		try {
			String sql = "select * from course";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				CourseDTO dto = new CourseDTO(rs.getString(1), rs.getString(2),
						rs.getString(3),
						selectMajorDepartment(rs.getString(4)),
						rs.getString(5), rs.getString(6), rs.getString(7),
						selectProfessorName(rs.getString(8)), rs.getString(9));
				allCourseDatas.add(dto);
			}
		} catch (SQLException e) {
			System.out.println("course�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allCourseDatas;
	}

	
	public ArrayList<String> selectMajorCodes() {
		ArrayList<String> allMajorCode = new ArrayList<String>();

		try {
			String sql = "select department from major";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				allMajorCode.add(rs.getString(1));
			}
		} catch (SQLException e) {
			System.out.println("major�� department�� ���� ���� ���߽��ϴ�");
		}
		return allMajorCode;
	}
	
	public ArrayList<CourseDTO> selectCategory(String categoryItem) {
		ArrayList<CourseDTO> allCourseDatas = new ArrayList<CourseDTO>();
		String sql = "";
		try {
			sql = "select code from major where department = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, categoryItem);
			rs = pstmt.executeQuery();
			
			sql = "select * from course where major_code = ?";
			pstmt = con.prepareStatement(sql);
			rs.next();
			pstmt.setString(1, rs.getString(1));
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				CourseDTO dto = new CourseDTO(rs.getString(1), rs.getString(2),
						rs.getString(3),
						selectMajorDepartment(rs.getString(4)),
						rs.getString(5), rs.getString(6), rs.getString(7),
						selectProfessorName(rs.getString(8)), rs.getString(9));
				allCourseDatas.add(dto);
			}
		} catch (SQLException e) {
			System.out.println(categoryItem + "�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allCourseDatas;
	}
	
	public String selectMajorDepartment(String code) {
		String department = "";
		PreparedStatement pstmt;
		ResultSet rs;
		try {
			String sql = "select department from major where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				department = rs.getString(1);
			}
		} catch (SQLException e) {
			System.out.println("major�� code�� �� ���� �Խ��ϴ�");
		}
		return department;
	}
	
	public String selectProfessorName(String code) {
		String name = "";
		PreparedStatement pstmt;
		ResultSet rs;
		try {
			String sql = "select name from professor where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				name = rs.getString(1);
			}
		} catch (SQLException e) {
			System.out.println("professor�� code�� �� ���� �Խ��ϴ�");
		}
		return name;
	}
	
	public String getDepartment(String code) {
		String department = "";
		PreparedStatement pstmt;
		ResultSet rs;
		try {
			String sql = "select department from major where code = (select major from student where code = ?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			rs = pstmt.executeQuery();
			rs.next();
			department = rs.getString(1);
		} catch (SQLException e) {
			System.out.println("major�� code�� �� ���� �Խ��ϴ�");
		}
		return department;
	}
}
