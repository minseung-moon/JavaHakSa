package Professor;

public class professor{
	public static void main(String[] args) {
		new ProfessorView();
	}
}
