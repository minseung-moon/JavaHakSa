package Student;

public class student{
	public static void main(String[] args) {
		new StudentView();
	}
}
