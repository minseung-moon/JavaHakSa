package Professor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class ProfessorBtnAction extends MouseAdapter implements ActionListener,
		KeyListener {
	private ProfessorView view;
	private ProfessorDAO dao;
	private ProfessorDTO professorDTO = new ProfessorDTO(null, null, null,
			null, null, null, null, null, null, null);
	private int rowIndex = -1;
	private JTable table;
	ArrayList<ProfessorDTO> selectAll;

	public ProfessorBtnAction(ProfessorView view) {
		super();
		this.view = view;
		view.BtnAddAction(this);
		view.MouseAddAction(this);
		view.KeyAddAction(this);
		table = view.table;
		dao = new ProfessorDAO();
		initSelect();
	}

	private void initSelect() {
		// ���̺��� �⺻ ������ ���
		view.dtm.setRowCount(0);
		selectAll = dao.selectProfessor();
		for (ProfessorDTO select : selectAll) {
			view.dtm.addRow(select.getArrays());
		}
	}

	public void clear() {
		view.code.setText("");
		view.code.setEnabled(true);
		view.name.setText("");
		view.userId1.setText("");
		view.userId2.setText("");
		view.address.setText("");
		view.mphone.setText("");
		view.hphone.setText("");
		view.ent_year.setText("");
		view.degree.setText("");
		view.major_code.setText("");
		view.roomno.setText("");
		view.tsearch.setText("");
		rowIndex = -1;
	}

	private boolean checkInput() {
		boolean check = false;
		if (view.code.getText() == null || view.code.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ڵ带 �Է����ּ���");
			view.code.requestFocus();
		} else if (view.name.getText() == null
				|| view.name.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "������ �Է����ּ���");
			view.name.requestFocus();
		} else if (view.userId1.getText() == null
				|| view.userId1.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ֹι�ȣ ���ڸ��� �Է����ּ���");
			view.userId1.requestFocus();
		} else if (view.userId2.getText() == null
				|| view.userId2.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ֹι�ȣ ���ڸ��� �Է����ּ���");
			view.userId2.requestFocus();
		} else if (view.address.getText() == null
				|| view.address.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ּҸ� �Է����ּ���");
			view.address.requestFocus();
		} else if (view.mphone.getText() == null
				|| view.mphone.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�޴��ȣ�� �Է����ּ���");
			view.mphone.requestFocus();
		} else if (view.hphone.getText() == null
				|| view.hphone.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "��ȭ��ȣ�� �Է����ּ���");
			view.hphone.requestFocus();
		} else if (view.ent_year.getText() == null
				|| view.ent_year.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�ӿ뿬���� �Է����ּ���");
			view.ent_year.requestFocus();
		} else if (view.degree.getText() == null
				|| view.degree.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "������ �Է����ּ���");
			view.degree.requestFocus();
		} else if (view.major_code.getText() == null
				|| view.major_code.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�а�/������ �Է����ּ���");
			view.major_code.requestFocus();
		} else if (view.roomno.getText() == null
				|| view.roomno.getText().equals("")) {
			JOptionPane.showMessageDialog(null, "�������� �Է����ּ���");
			view.roomno.requestFocus();
		} else {
			check = true;
			professorDTO = new ProfessorDTO(view.code.getText(),
					view.name.getText(), view.userId1.getText() + "-"
							+ view.userId2.getText(), view.address.getText(),
					view.mphone.getText(), view.hphone.getText(),
					view.ent_year.getText(), view.degree.getText(),
					view.major_code.getText(), view.roomno.getText());
		}
		return check;
	}

	private void selectCategory(int num, String searchStr) {
		// ���̺��� �⺻ ������ ���
		view.dtm.setRowCount(0);
		selectAll = dao.selectCategory(num, searchStr);
		for (ProfessorDTO select : selectAll) {
			String[] major = select.toString().split(",");
			view.dtm.addRow(major);
		}
	}

	private void updateTable(int rowIndex) {
		table.setValueAt(professorDTO.getCode(), rowIndex, 0);
		table.setValueAt(professorDTO.getName(), rowIndex, 1);
		table.setValueAt(professorDTO.getUserId(), rowIndex, 2);
		table.setValueAt(professorDTO.getAddress(), rowIndex, 3);
		table.setValueAt(professorDTO.getMphone(), rowIndex, 4);
		table.setValueAt(professorDTO.getHphone(), rowIndex, 5);
		table.setValueAt(professorDTO.getEnt_year(), rowIndex, 6);
		table.setValueAt(professorDTO.getDegree(), rowIndex, 7);
		table.setValueAt(professorDTO.getMajor_code(), rowIndex, 8);
		table.setValueAt(professorDTO.getRoomno(), rowIndex, 9);
		JOptionPane.showMessageDialog(null, "���� �Ǿ����ϴ�");
	}

	public void mouseClicked(MouseEvent e) {
		rowIndex = table.getSelectedRow();
		if (rowIndex == -1 || e.getSource() != table) {
			clear();
			return;
		}
		professorDTO.setCode(table.getValueAt(rowIndex, 0).toString());
		professorDTO.setName(table.getValueAt(rowIndex, 1).toString());
		professorDTO.setUserId(table.getValueAt(rowIndex, 2).toString());
		professorDTO.setAddress(table.getValueAt(rowIndex, 3).toString());
		professorDTO.setMphone(table.getValueAt(rowIndex, 4).toString());
		professorDTO.setHphone(table.getValueAt(rowIndex, 5).toString());
		professorDTO.setEnt_year(table.getValueAt(rowIndex, 6).toString());
		professorDTO.setDegree(table.getValueAt(rowIndex, 7).toString());
		professorDTO.setMajor_code(table.getValueAt(rowIndex, 8).toString());
		professorDTO.setRoomno(table.getValueAt(rowIndex, 9).toString());
		view.code.setText(professorDTO.getCode());
		view.code.setEnabled(false);
		view.name.setText(professorDTO.getName());
		String[] userIdArr = professorDTO.getUserId().split("-");
		view.userId1.setText(userIdArr[0]);
		view.userId2.setText(userIdArr[1]);
		view.address.setText(professorDTO.getAddress());
		view.mphone.setText(professorDTO.getMphone());
		view.hphone.setText(professorDTO.getHphone());
		view.ent_year.setText(professorDTO.getEnt_year());
		view.degree.setText(professorDTO.getDegree());
		view.major_code.setText(professorDTO.getMajor_code());
		view.roomno.setText(professorDTO.getRoomno());
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		if (obj == view.input) {
			if (!checkInput())
				return;

			int confirm = JOptionPane.showConfirmDialog(null, "���� "
					+ professorDTO.getCode() + "�� �߰��Ͻðڽ��ϱ�?", "�а��߰�",
					JOptionPane.OK_CANCEL_OPTION);
			if (confirm != 0) {
				JOptionPane.showMessageDialog(null, "�а��߰��� ����ϼ̽��ϴ�");
				return;
			}
			if (dao.inserProfessor(professorDTO)) {
				JOptionPane.showMessageDialog(null, "���忡 �����ϼ̽��ϴ�");
				view.dtm.addRow(professorDTO.getArrays());
			} else
				JOptionPane.showMessageDialog(null, "���忡 �����ϼ̽��ϴ�!");
		} else if (obj == view.edit) {
			if (!checkInput())
				return;
			int check = JOptionPane.showConfirmDialog(null,
					professorDTO.getCode() + "�� ���� �Ͻðڽ��ϱ�?", "���� ����",
					JOptionPane.YES_NO_OPTION);

			if (check == 1) {
				JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�");
				return;
			} else {
				if (rowIndex != -1 && dao.updateProfessor(professorDTO)) {
					updateTable(rowIndex);
				} else if (rowIndex == -1 && dao.updateProfessor(professorDTO)) {
					for (int i = 0; i < view.table.getRowCount(); i++) {
						if (table.getValueAt(i, 0).toString()
								.equals(professorDTO.getCode())) {
							rowIndex = i;
							break;
						}
					}
					updateTable(rowIndex);
				} else
					JOptionPane.showMessageDialog(null, "�����ͺ��̽� ������ �����Ͽ����ϴ�!");
			}
		} else if (obj == view.delte) {
			rowIndex = table.getSelectedRow();
			if (rowIndex == -1) {
				JOptionPane.showMessageDialog(null, "������ ���� �������ּ���!");
				return;
			} else {
				String code = table.getValueAt(rowIndex, 0).toString();
				int check = JOptionPane.showConfirmDialog(null, code
						+ "�� ���� �����Ͻðڽ��ϱ�?", "���� ����", JOptionPane.YES_NO_OPTION);
				if (check == 0) {
					if (dao.deleteProfessor(code)) {
						view.dtm.removeRow(rowIndex);
						JOptionPane.showMessageDialog(null, "���� �Ǿ����ϴ�");
					} else {
						JOptionPane.showMessageDialog(null,
								"�����ͺ��̽��� �������� ���߽��ϴ�!");
					}
				} else {
					JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�");
				}
			}
		} else if (obj == view.exit) {
			dao.close();
			view.close();
		} else if (obj == view.bsearch) {
			// 0 ~ 4
			int menuNum = view.search.getSelectedIndex();
			String searchStr = view.tsearch.getText();
			if (searchStr == null || searchStr.equals("")) {
				JOptionPane.showMessageDialog(null, "�˻��׸��� �Է����ּ���!");
				view.tsearch.requestFocus();
				return;
			}

			if (menuNum != 0) {
				selectCategory(menuNum, searchStr);
			} else {
				JOptionPane.showMessageDialog(null, "�޴��� �����ϼ���!");
			}

		} else if (obj == view.tbsearch) {
			initSelect();
		}

		clear();
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyTyped(KeyEvent e) {
		JTextField field = (JTextField) e.getSource();
		int limitLength = 0;
		if (field == view.code || field == view.name || field == view.ent_year
				|| field == view.degree || field == view.major_code
				|| field == view.roomno)
			limitLength = 10;
		else if (field == view.mphone || field == view.hphone)
			limitLength = 15;
		else if (field == view.address)
			limitLength = 45;
		else if (field == view.userId1)
			limitLength = 6;
		else if (field == view.userId2)
			limitLength = 7;

		if (field.getText().length() >= limitLength)
			e.consume();
	}

}
