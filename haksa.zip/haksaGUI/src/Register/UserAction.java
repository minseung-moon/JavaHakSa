package Register;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;

import Course.CourseDTO;

public class UserAction extends MouseAdapter implements ActionListener {
	private UserView view;
	private UserDAO userDAO;
	private LoginDTO userDTO = new LoginDTO(null, null, null, null, null);
	private int rowIndex = -1;
	private JTable table;
	ArrayList<LoginDTO> selectAll;
	
	public UserAction(UserView view) {
		super();
		this.view = view;
		table = view.table;
		userDAO = new UserDAO();
		ArrayList<String> allCode = userDAO.selectCodeList();
		allCode.forEach(item -> {
			view.ownerBox.addItem(item);
		});
		view.BtnAddAction(this);
		view.MouseAddAction(this);
		initSelect();
	}
	
	private void initSelect() {
		// ���̺��� �⺻ ������ ���
		view.dtm.setRowCount(0);
		selectAll = userDAO.selectUser();
		for (LoginDTO select : selectAll) {
			view.dtm.addRow(select.getArrays());
		}
	}
	
	public void clear() {
		for (JTextField field : view.inputFields) {
			field.setText("");
		}
		view.categoryField.setText("");
		view.authBox.setSelectedIndex(0);
		view.ownerBox.setSelectedIndex(0);
		view.categoryBox.setSelectedIndex(0);
		rowIndex = -1;
	}
	
	private boolean checkInput() {
		boolean check = false;
		for (JTextField field : view.inputFields) {
			if (field.getText() == null || field.getText().equals("")) {
				JOptionPane.showMessageDialog(null, "��ĭ�� ä���ּ���");
				field.requestFocus();
				return check;
			}
		}
		if(view.authBox.getSelectedIndex() == 0) {
			JOptionPane.showMessageDialog(null, "�������ּ���");
			view.authBox.requestFocus();
			return check;
		}
		if(view.ownerBox.getSelectedIndex() == 0) {
			JOptionPane.showMessageDialog(null, "�������ּ���");
			view.ownerBox.requestFocus();
			return check;
		}
		check = true;
		userDTO.setId(view.inputFields[0].getText());
		userDTO.setPassword(view.inputFields[1].getText());
		userDTO.setOwner(view.ownerBox.getSelectedItem().toString());
		userDTO.setAuth(view.authBox.getSelectedItem().toString());
		return check;
	}
	
	private void selectCategory(int num, String searchStr) {
		// ���̺��� �⺻ ������ ���
		view.dtm.setRowCount(0);
		selectAll = userDAO.selectCategory(num, searchStr);
		for (LoginDTO select : selectAll) {
			view.dtm.addRow(select.getArrays());
		}
	}
	
	private void updateTable(int rowIndex) {
		table.setValueAt(userDTO.getId(), rowIndex, 0);
		table.setValueAt(userDTO.getPassword(), rowIndex, 1);
		table.setValueAt(userDTO.getOwner(), rowIndex, 2);
		table.setValueAt(userDTO.getAuth(), rowIndex, 3);
		table.setValueAt(userDTO.getDate(), rowIndex, 4);
		JOptionPane.showMessageDialog(null, "���� �Ǿ����ϴ�");
	}
	
	public void mouseClicked(MouseEvent e) {
		rowIndex = table.getSelectedRow();
		if (rowIndex == -1 || e.getSource() != table) {
			clear();
			return;
		}
		
		userDTO.setId(table.getValueAt(rowIndex, 0).toString());
		userDTO.setPassword(table.getValueAt(rowIndex, 1).toString());
		userDTO.setOwner(table.getValueAt(rowIndex, 2).toString());
		userDTO.setAuth(table.getValueAt(rowIndex, 3).toString());
		userDTO.setDate(table.getValueAt(rowIndex, 4).toString());

		view.inputFields[0].setText(userDTO.getId());
		view.inputFields[0].setEnabled(false);
		view.inputFields[1].setText(userDTO.getPassword());
		view.ownerBox.setSelectedItem(userDTO.getOwner());
		view.authBox.setSelectedItem(userDTO.getAuth());
	}
	
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();

		if (obj == view.submitBtns[0]) {
			if (!checkInput())
				return;

			int confirm = JOptionPane.showConfirmDialog(null,
					"����" + userDTO.getId() + "�� �߰��Ͻðڽ��ϱ�?", "������߰�",
					JOptionPane.OK_CANCEL_OPTION);
			if (confirm != 0) {
				JOptionPane.showMessageDialog(null, "������߰��� ����ϼ̽��ϴ�");
				return;
			}

			if (userDAO.inserUser(userDTO)) {
				System.out.println(1);
				JOptionPane.showMessageDialog(null, "���忡 �����ϼ̽��ϴ�");
				initSelect();
			} else
				JOptionPane.showMessageDialog(null, "���忡 �����ϼ̽��ϴ�!");
		} else if (obj == view.submitBtns[1]) {
			if (!checkInput())
				return;

			int check = JOptionPane.showConfirmDialog(null, userDTO.getId()
					+ "�� ���� �Ͻðڽ��ϱ�?", "���� ����", JOptionPane.YES_NO_OPTION);

			if (check == 1) {
				JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�");
				return;
			} else {
				if (rowIndex != -1 && userDAO.updateUser(userDTO)) {
					updateTable(rowIndex);
				} else if (rowIndex == -1 && userDAO.updateUser(userDTO)) {
					for (int i = 0; i < view.table.getRowCount(); i++) {
						if (table.getValueAt(i, 0).toString()
								.equals(userDTO.getId())) {
							rowIndex = i;
							break;
						}
					}
					updateTable(rowIndex);
				} else
					JOptionPane.showMessageDialog(null, "�����ͺ��̽� ������ �����Ͽ����ϴ�!");
			}
		} else if (obj == view.submitBtns[2]) {
			rowIndex = table.getSelectedRow();
			if (rowIndex == -1) {
				JOptionPane.showMessageDialog(null, "������ ���� �������ּ���!");
				return;
			} else {
				String code = table.getValueAt(rowIndex, 0).toString();
				int check = JOptionPane.showConfirmDialog(null, code
						+ "�� ���� �����Ͻðڽ��ϱ�?", "���� ����", JOptionPane.YES_NO_OPTION);
				if (check == 0) {
					if (userDAO.deleteUser(code)) {
						view.dtm.removeRow(rowIndex);
						JOptionPane.showMessageDialog(null, "���� �Ǿ����ϴ�");
					} else {
						JOptionPane.showMessageDialog(null,
								"�����ͺ��̽��� �������� ���߽��ϴ�!");
					}
				} else {
					JOptionPane.showMessageDialog(null, "��� �Ǿ����ϴ�");
				}
			}
		} else if (obj == view.submitBtns[3]) {
			userDAO.close();
			view.close();
		} else if (obj == view.categoryBtns[0]) {
			// 0 ~ 4
			int menuNum = view.categoryBox.getSelectedIndex();
			String searchStr = view.categoryField.getText();
			if (searchStr == null || searchStr.equals("")) {
				JOptionPane.showMessageDialog(null, "�˻��׸��� �Է����ּ���!");
				view.categoryField.requestFocus();
				return;
			}

			if (menuNum != 0) {
				selectCategory(menuNum, searchStr);
			} else {
				JOptionPane.showMessageDialog(null, "�޴��� �����ϼ���!");
			}

		} else if (obj == view.categoryBtns[1]) {
			initSelect();
		}

		clear();
	}
}
