package haksa;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import Course.CourseView;
import Major.MajorView;
import Professor.ProfessorView;
import Register.UserView;
import Student.StudentView;
import Class.ClassView;

public class HaksaAction implements ActionListener{
	private HaksaMenu haksaMenu;
	
	public HaksaAction(HaksaMenu haksaMenu) {
		this.haksaMenu = haksaMenu;
		haksaMenu.ItemAddAction(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object obj = e.getSource();
		
		if(obj == haksaMenu.majorMenuItem) new MajorView();
		else if(obj == haksaMenu.professorMenuItem) new ProfessorView();
		else if(obj == haksaMenu.studentMenuItem) new StudentView();
		else if(obj == haksaMenu.courseMenuItem) new CourseView();
		else if(obj == haksaMenu.userMenuItem) new  UserView();
		else if(obj == haksaMenu.classMenuItem) {
			new ClassView(haksaMenu.loginDTO, haksaMenu.username);
			System.out.println(haksaMenu.loginDTO);
			System.out.println(haksaMenu.username);
		}
	}
}
