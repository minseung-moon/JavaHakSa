package haksa;

import java.awt.Event;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.KeyStroke;

import Register.LoginDTO;

public class HaksaMenu extends JFrame {

	private static final long serialVersionUID = 1L;
	JMenuBar menuBar;
	String[] menuStr = { "�а�����", "��������", "�л�����", "���������", "����ڰ���", "������û" };
	JMenu[] menus = new JMenu[menuStr.length];
	JMenuItem majorMenuItem, professorMenuItem, studentMenuItem, courseMenuItem, userMenuItem, classMenuItem;
	LoginDTO loginDTO;
	String username;
	
	public HaksaMenu(LoginDTO loginDTO, String username) {
		this.loginDTO = loginDTO;
		this.username = username;
		setTitle("�л�����ý��� : ����� : "+loginDTO.getOwner() + " "+username);
		setSize(1000, 800);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		menuBar = new JMenuBar();
		for (int i = 0; i < menuStr.length; i++) {
			menus[i] = new JMenu(menuStr[i]);
		}
		majorMenuItem = new JMenuItem("�а� ���");
		professorMenuItem = new JMenuItem("���� ���");
		studentMenuItem = new JMenuItem("�л� ���");
		courseMenuItem = new JMenuItem("������ ����");
		userMenuItem = new JMenuItem("����� ����");
		classMenuItem = new JMenuItem("���� ��û");
		
		menus[0].add(majorMenuItem);
		menus[1].add(professorMenuItem);
		menus[2].add(studentMenuItem);
		menus[3].add(courseMenuItem);
		menus[4].add(userMenuItem);
		menus[5].add(classMenuItem);
		
		this.setJMenuBar(menuBar);
		
		// ����Ű
		majorMenuItem.setAccelerator(KeyStroke.getKeyStroke('M',Event.CTRL_MASK));
		professorMenuItem.setAccelerator(KeyStroke.getKeyStroke('P',Event.CTRL_MASK));
		studentMenuItem.setAccelerator(KeyStroke.getKeyStroke('S',Event.CTRL_MASK));
//		fileItems[1].setAccelerator(KeyStroke.getKeyStroke('S',
//				InputEvent.CTRL_MASK ^ InputEvent.SHIFT_MASK));

//		textPane.addMouseListener(new MouseAdapter() {
//			@Override
//			public void mousePressed(MouseEvent e) {
//				// ������ ���콺 ��ư�� ������ PopupMenu�� ȭ�鿡 �����ش�.
//				if (e.getButton() == MouseEvent.BUTTON3)
//					popupMenu.show(textPane, e.getX(), e.getY());
//			}
//		});

		new HaksaAction(this);
		init(loginDTO.getAuth());
		this.setVisible(true);
	}
	
	public void init(String getAuth) {
		String auth = getAuth.toLowerCase();
		if(auth.equals("p")){
			menuBar.add(menus[0]);
			menuBar.add(menus[1]);
			menuBar.add(menus[3]);
			menuBar.add(menus[4]);
		}else {
			menuBar.add(menus[2]);
			menuBar.add(menus[5]);
		}
	}

	public void ItemAddAction(ActionListener listener) {
		majorMenuItem.addActionListener(listener);
		professorMenuItem.addActionListener(listener);
		studentMenuItem.addActionListener(listener);
		courseMenuItem.addActionListener(listener);
		userMenuItem.addActionListener(listener);
		classMenuItem.addActionListener(listener);
	}
}
