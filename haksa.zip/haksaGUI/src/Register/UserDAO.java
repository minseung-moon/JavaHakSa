package Register;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import javax.swing.JOptionPane;

import Course.CourseDTO;
import haksa.DBConn;

public class UserDAO {
	DBConn conn;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;
	
	public UserDAO() {
		conn = new DBConn();
		con = conn.conn;
	}
	
	public void close() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn.conn != null)
				con.close();
		} catch (Exception e) {
			System.out.println("���� ����");
		}
	}
	
	public ArrayList<LoginDTO> selectUser() {
		ArrayList<LoginDTO> allUserDates = new ArrayList<LoginDTO>();
		
		try {
			String sql = "select * from admin";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				LoginDTO dto = new LoginDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
				allUserDates.add(dto);
			}
		} catch (Exception e) {
			System.out.println("User�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allUserDates;
	}
	
	public boolean inserUser(LoginDTO user) {
		boolean check = false;
		try {
			String sql = "insert into admin values (?, ?, ?, ?, ?);";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, user.getId());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getOwner());
			pstmt.setString(4, user.getAuth());
			DateFormat format = new SimpleDateFormat("yyyy-MM-dd");
			String datestr = format.format(Calendar.getInstance().getTime());
			pstmt.setString(5, datestr);
			int num = pstmt.executeUpdate();

			if (num == 1)
				check = true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "�̹� �����ϴ� ����� �Դϴ�");
		}
		return check;
	}
	
	public boolean updateUser(LoginDTO user) {
		boolean check = false;

		try {
			String sql = "update admin set password = ?, owner = ?, auth = ? where id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, user.getPassword());
			pstmt.setString(2, user.getOwner());
			pstmt.setString(3, user.getAuth());
			pstmt.setString(4, user.getId());
			int num = pstmt.executeUpdate();
			if (num == 1)
				check = true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "������ ���� �Ͽ����ϴ�");
		}
		return check;
	}
	
	public boolean deleteUser(String id) {
		boolean check = false;

		try {
			String sql = "delete from admin where id = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, id);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				check = true;
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "�������� �ʴ� ����� �Դϴ�!");
			e.printStackTrace();
		}
		return check;
	}
	
	
	public ArrayList<LoginDTO> selectCategory(int num, String searchStr) {
		ArrayList<LoginDTO> allUserDatas = new ArrayList<LoginDTO>();
		String sql = "";
		try {
			if (num == 1) {
				sql = "select * from admin where id = ?";
			} else if (num == 2) {
				sql = "select * from admin where password = ?";
			} else if (num == 3) {
				sql = "select * from admin where owner = ?";
			} else if (num == 4) {
				sql = "select * from admin where auth = ?";
			} else if (num == 5) {
				sql = "select * from admin where date = ?";
			}

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, searchStr);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				LoginDTO dto2 = new LoginDTO(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5));
				allUserDatas.add(dto2);
			}
		} catch (SQLException e) {
			System.out.println(searchStr + "�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allUserDatas;
	}
	
	
	
	public ArrayList<String> selectCodeList() {
		ArrayList<String> allCode = new ArrayList<String>();

		try {
			String sql = "select code from student";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				allCode.add(rs.getString(1));
			}
			sql = "select code from professor";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				allCode.add(rs.getString(1));
			}
		} catch (SQLException e) {
			System.out.println("������� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allCode;
	}
}
