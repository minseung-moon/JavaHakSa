package Course;

import haksa.DBConn;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import Student.StudentDTO;

public class CourseDAO {
	DBConn conn;
	Connection con;
	PreparedStatement pstmt;
	ResultSet rs;

	public CourseDAO() {
		conn = new DBConn();
		con = conn.conn;
	}

	public void close() {
		try {
			if (rs != null)
				rs.close();
			if (pstmt != null)
				pstmt.close();
			if (conn.conn != null)
				con.close();
		} catch (Exception e) {
			System.out.println("���� ����");
		}
	}

	public ArrayList<CourseDTO> selectCourse() {
		ArrayList<CourseDTO> allCourseDatas = new ArrayList<CourseDTO>();

		try {
			String sql = "select * from course";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				CourseDTO dto = new CourseDTO(rs.getString(1), rs.getString(2),
						rs.getString(3),
						selectMajorDepartment(rs.getString(4)),
						rs.getString(5), rs.getString(6), rs.getString(7),
						selectProfessorName(rs.getString(8)), rs.getString(9));
				allCourseDatas.add(dto);
			}
		} catch (SQLException e) {
			System.out.println("Student�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allCourseDatas;
	}

	public boolean inserCourse(CourseDTO course) {
		boolean check = false;
		try {
			String sql = "insert into course values (?, ?, ?, ?, ?, ?, ?, ?, ?);";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, course.getCode());
			pstmt.setString(2, course.getSubject());
			pstmt.setString(3, course.getYear());
			pstmt.setString(4, selectMajorCode(course.getMajor_code()));
			pstmt.setString(5, course.getGrade());
			pstmt.setString(6, course.getTerm());
			pstmt.setString(7, course.getTime());
			pstmt.setString(8, selectProfessorCode(course.getProf_code()));
			pstmt.setString(9, course.getCredit());
			int num = pstmt.executeUpdate();

			if (num == 1)
				check = true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "�̹� �����ϴ� ������ �Դϴ�");
		}
		return check;
	}

	public boolean updateCourse(CourseDTO course) {
		boolean check = false;

		try {
			String sql = "update course set subject = ?, year = ?, major_code = ?, grade = ?, term = ?,"
					+ " time = ?, prof_code = ?, credit = ? where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, course.getSubject());
			pstmt.setString(2, course.getYear());
			String major_code = selectMajorCode(course.getMajor_code());
			pstmt.setString(3, major_code);
			pstmt.setString(4, course.getGrade());
			pstmt.setString(5, course.getTerm());
			pstmt.setString(6, course.getTerm());
			String prof_code = selectProfessorCode(course.getCredit());
			pstmt.setString(7, prof_code);
			pstmt.setString(8, course.getCredit());
			pstmt.setString(9, course.getCode());
			int num = pstmt.executeUpdate();
			if (num == 1)
				check = true;
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "������ ���� �Ͽ����ϴ�");
		}
		return check;
	}

	public boolean deleteCourse(String code) {
		boolean check = false;

		try {
			String sql = "delete from course where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			int i = pstmt.executeUpdate();
			if (i == 1) {
				check = true;
			}
		} catch (SQLException e) {
			JOptionPane.showMessageDialog(null, "�������� �ʴ� ������ �Դϴ�!");
			e.printStackTrace();
		}
		return check;
	}

	public ArrayList<CourseDTO> selectCategory(int num, String searchStr) {
		ArrayList<CourseDTO> allCourseDatas = new ArrayList<CourseDTO>();
		String sql = "";
		try {
			if (num == 1) {
				sql = "select * from course where code = ?";
			} else if (num == 2) {
				sql = "select * from course where subject = ?";
			} else if (num == 3) {
				sql = "select * from course where year = ?";
			} else if (num == 4) {
				searchStr = selectMajorCode(searchStr);
				sql = "select * from course where major_code = ?";
			} else if (num == 5) {
				sql = "select * from course where grade = ?";
			} else if (num == 6) {
				sql = "select * from course where term = ?";
			} else if (num == 7) {
				sql = "select * from course where time = ?";
			} else if (num == 8) {
				searchStr = selectMajorDepartment(searchStr);
				sql = "select * from course where prof_code = ?";
			} else if (num == 9) {
				sql = "select * from course where credit = ?";
			}

			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, searchStr);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				String deparment = selectMajorDepartment(rs.getString(4));
				String name = selectMajorDepartment(rs.getString(8));
				CourseDTO dto = new CourseDTO(rs.getString(1), rs.getString(2),
						rs.getString(3), deparment, rs.getString(5),
						rs.getString(6), rs.getString(7), name, rs.getString(9));
				allCourseDatas.add(dto);
			}
		} catch (SQLException e) {
			System.out.println(searchStr + "�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allCourseDatas;
	}

	public ArrayList<String> selectMajorName() {
		ArrayList<String> allMajorCode = new ArrayList<String>();

		try {
			String sql = "select department from major ";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				allMajorCode.add(rs.getString(1));
			}
		} catch (SQLException e) {
			System.out.println("major�� ��ü �����͸� ���� ���� ���߽��ϴ�");
		}
		return allMajorCode;
	}

	public ArrayList<String> selectProfessorNames() {
		ArrayList<String> allProfessorCode = new ArrayList<String>();

		try {
			String sql = "select name from professor ";
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				allProfessorCode.add(rs.getString(1));
			}
		} catch (SQLException e) {
			System.out.println("professor�� name�� ���� ���� ���߽��ϴ�");
		}
		return allProfessorCode;
	}

	public String selectMajorCode(String department) {
		String code = "";
		PreparedStatement pstmt;
		try {
			String sql = "select code from major where department = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, department);
			rs = pstmt.executeQuery();

			while (rs.next()) {
				code = rs.getString(1);
			}
		} catch (SQLException e) {
			System.out.println("major�� code�� �� ���� �Խ��ϴ�");
		}
		return code;
	}

	public String selectProfessorCode(String name) {
		String code = "";
		PreparedStatement pstmt;
		try {
			String sql = "select code from professor where name = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				code = rs.getString(1);
			}
		} catch (SQLException e) {
			System.out.println("professor�� code�� �� ���� �Խ��ϴ�");
		}
		System.out.println(code);
		return code;
	}

	public String selectMajorDepartment(String code) {
		String department = "";
		PreparedStatement pstmt;
		ResultSet rs;
		try {
			String sql = "select department from major where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				department = rs.getString(1);
			}
		} catch (SQLException e) {
			System.out.println("major�� code�� �� ���� �Խ��ϴ�");
		}
		return department;
	}

	public String selectProfessorName(String code) {
		String name = "";
		PreparedStatement pstmt;
		ResultSet rs;
		try {
			String sql = "select name from professor where code = ?";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, code);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				name = rs.getString(1);
			}
		} catch (SQLException e) {
			System.out.println("professor�� code�� �� ���� �Խ��ϴ�");
		}
		return name;
	}
}
